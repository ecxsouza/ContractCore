// ================================================================
// ContractCore — Tipos Globais
// Modelados pela Mesa Técnica Multidisciplinar
// ================================================================

// ── ENUMS ────────────────────────────────────────────────────────

export type PersonType = 'PJ' | 'MEI' | 'PF';

export type ProfessionType =
  | 'psicologo'
  | 'neuropsicologo'
  | 'fonoaudiologo'
  | 'psicopedagogo'
  | 'secretaria'
  | 'recepcionista'
  | 'coordenador'
  | 'outro';

export type ModalityType = 'presencial' | 'online' | 'hibrido';

export type RemunerationModel =
  | 'fixo_mensal'
  | 'por_atendimento'
  | 'por_hora'
  | 'por_plantao'
  | 'percentual'
  | 'pacote'
  | 'reembolso'
  | 'bonus'
  | 'outro';

export type PaymentMethod = 'pix' | 'transferencia' | 'boleto' | 'dinheiro' | 'outro';

export type ContractStatus =
  | 'rascunho'
  | 'revisao_ia'
  | 'aguardando_assinatura'
  | 'assinado'
  | 'encerrado'
  | 'cancelado';

export type AIStatus = 'disponivel' | 'processando' | 'indisponivel' | 'revisado';

// ── EMPRESA CONTRATANTE ──────────────────────────────────────────

export interface Company {
  id: string;
  user_id: string;
  razao_social: string;
  nome_fantasia: string;
  cnpj: string;
  inscricao_municipal?: string;
  data_abertura?: string;
  porte?: string;
  natureza_juridica?: string;
  atividade_principal?: string;
  // Endereço desmembrado
  cep: string;
  logradouro: string;
  numero: string;
  complemento?: string;
  bairro: string;
  cidade: string;
  uf: string;
  // Contato
  email: string;
  telefone: string;
  // Responsável legal
  responsavel_legal: string;
  cpf_responsavel: string;
  // Logo
  logo_url?: string;
  // Bancário
  banco?: string;
  agencia?: string;
  conta?: string;
  tipo_conta?: 'corrente' | 'poupanca';
  pix_key?: string;
  // Metadados
  created_at: string;
  updated_at: string;
}

// ── PRESTADOR DE SERVIÇOS ─────────────────────────────────────────

export interface ServiceProvider {
  id: string;
  company_id: string;
  // Tipo jurídico
  tipo_pessoa: PersonType;
  // Dados pessoais/empresariais
  nome_razao_social: string;
  nome_fantasia?: string;
  cpf?: string;
  cnpj?: string;
  rg?: string;
  inscricao_municipal?: string;
  // Profissional
  profissao: ProfessionType;
  profissao_descricao?: string; // quando "outro"
  especialidade?: string;
  conselho_profissional?: string;
  numero_registro_conselho?: string;
  // Endereço
  cep: string;
  logradouro: string;
  numero: string;
  complemento?: string;
  bairro: string;
  cidade: string;
  uf: string;
  // Contato
  email: string;
  telefone: string;
  // Responsável legal (PJ)
  responsavel_legal?: string;
  cpf_responsavel?: string;
  // Dados pessoais (PF)
  estado_civil?: string;
  nacionalidade?: string;
  // Metadados
  created_at: string;
  updated_at: string;
}

// ── DADOS DA PRESTAÇÃO ────────────────────────────────────────────

export interface ServiceDetails {
  objeto: string;
  descricao_servicos?: string;
  local_prestacao: string;
  modalidade: ModalityType;
  periodicidade: string;
  agenda_pactuada?: string;
  horarios?: string;
  exclusividade: boolean;
  recursos_disponibilizados: string[];
  recursos_personalizados?: string[];
  // Regras operacionais
  regra_cancelamento?: string;
  regra_falta?: string;
  regra_atraso?: string;
  regra_remarcacao?: string;
  resp_materiais?: string;
  resp_documentos?: string;
  regra_comunicacao_pacientes?: string;
  regra_uso_marca?: string;
  regra_redes_sociais?: string;
  regra_captacao_pacientes?: string;
  condutas_vedadas?: string;
}

// ── REMUNERAÇÃO ───────────────────────────────────────────────────

export interface RemunerationDetails {
  modelos: RemunerationModel[];
  valor_descricao: string; // ex: "R$ 250,00 por atendimento"
  valor_fixo_mensal?: number;
  valor_por_atendimento?: number;
  valor_por_hora?: number;
  percentual?: number;
  data_pagamento: string;
  formas_pagamento: PaymentMethod[];
  emite_nota_fiscal: 'obrigatorio' | 'dispensado_mei' | 'a_definir';
  retencoes_fiscais?: string;
  reembolso_tipo?: string;
  reembolso_descricao?: string;
}

// ── CONTRATO ──────────────────────────────────────────────────────

export interface Contract {
  id: string;
  company_id: string;
  provider_id: string;
  // Identificação
  numero_contrato: string;  // ex: CC-2024-0001
  versao: number;
  status: ContractStatus;
  // Datas
  data_emissao: string;
  data_vigencia_inicio?: string;
  data_vigencia_fim?: string;  // null = indeterminado
  vigencia_indeterminada: boolean;
  // Dados da prestação
  service_details: ServiceDetails;
  remuneration: RemunerationDetails;
  // Anexos selecionados
  anexos: AnexoType[];
  // Texto do contrato
  contrato_html?: string;
  contrato_revisado_ia?: string;
  // PDF
  pdf_url?: string;
  // IA
  ia_revisado: boolean;
  ia_revisado_em?: string;
  ia_sugestoes?: string;
  // Assinatura
  assinado_contratante: boolean;
  assinado_prestador: boolean;
  data_assinatura_contratante?: string;
  data_assinatura_prestador?: string;
  ip_assinatura_contratante?: string;
  ip_assinatura_prestador?: string;
  hash_documento?: string;
  // Notas
  notas_internas?: string;
  // Metadados
  created_at: string;
  updated_at: string;
  // Joins
  company?: Company;
  provider?: ServiceProvider;
}

// ── VERSÃO DE CONTRATO ────────────────────────────────────────────

export interface ContractVersion {
  id: string;
  contract_id: string;
  versao: number;
  contrato_html: string;
  alteracoes_resumo?: string;
  alterado_por?: string;
  created_at: string;
}

// ── ANEXOS ────────────────────────────────────────────────────────

export type AnexoType =
  | 'confidencialidade'
  | 'lgpd'
  | 'prontuarios'
  | 'uso_estrutura'
  | 'politica_agenda'
  | 'sem_vinculo_clt'
  | 'checklist_pj_mei'
  | 'checklist_pejotizacao'
  | 'checklist_conselho'
  | 'ciencia_etica';

export interface AnexoInfo {
  id: AnexoType;
  titulo: string;
  descricao: string;
  quando_usar: string;
  obrigatorio_para?: ProfessionType[];
}

// ── LOG DE IA ─────────────────────────────────────────────────────

export interface AILog {
  id: string;
  company_id: string;
  contract_id?: string;
  tipo: 'revisao' | 'sugestao_objeto' | 'sugestao_clausula' | 'analise_risco';
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  modelo: string;
  created_at: string;
}

// ── FORMULÁRIO DE NOVO CONTRATO (multi-step) ──────────────────────

export interface ContractFormData {
  // Step 1 — Prestador
  provider: Omit<ServiceProvider, 'id' | 'company_id' | 'created_at' | 'updated_at'>;
  // Step 2 — Serviço
  service: ServiceDetails;
  // Step 3 — Remuneração
  remuneration: RemunerationDetails;
  // Step 4 — Anexos & Revisão
  anexos: AnexoType[];
  vigencia_indeterminada: boolean;
  data_vigencia_inicio?: string;
  data_vigencia_fim?: string;
  notas_internas?: string;
}

// ── CNPJ API RESPONSE ─────────────────────────────────────────────

export interface CNPJData {
  razao_social: string;
  nome_fantasia?: string;
  cnpj: string;
  situacao_cadastral: string;
  data_abertura: string;
  porte: string;
  natureza_juridica: string;
  atividade_principal: string;
  logradouro: string;
  numero: string;
  complemento?: string;
  bairro: string;
  municipio: string;
  uf: string;
  cep: string;
  email?: string;
  telefone?: string;
}

// ── CEP API RESPONSE ──────────────────────────────────────────────

export interface CEPData {
  cep: string;
  logradouro: string;
  complemento?: string;
  bairro: string;
  localidade: string;
  uf: string;
  erro?: boolean;
}

// ── UI / WIZARD ───────────────────────────────────────────────────

export interface WizardStep {
  id: number;
  titulo: string;
  descricao: string;
  icone: string;
  completo: boolean;
}

// ── IA / MESA TÉCNICA ─────────────────────────────────────────────

export interface RiscoItem {
  titulo:        string;
  descricao:     string;
  gravidade:     'atencao' | 'importante' | 'critico';
  como_corrigir: string;
  area:          string;
}

export interface ChecklistMesaItem {
  area:       string;
  status:     'ok' | 'atencao' | 'problema';
  observacao: string;
}
