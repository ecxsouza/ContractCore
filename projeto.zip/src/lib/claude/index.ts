// ================================================================
// ContractCore — Integração Claude / Mesa Técnica Multidisciplinar
// ================================================================
import Anthropic from '@anthropic-ai/sdk';
import type { ContractFormData, Company, RiscoItem, ChecklistMesaItem } from '@/types';

export type { RiscoItem, ChecklistMesaItem };

const client = new Anthropic({
  apiKey:  process.env.ANTHROPIC_API_KEY!,
  timeout: 58000,
});

const VALID_MODELS = [
  'claude-opus-4-8',
  'claude-sonnet-4-6',
  'claude-haiku-4-5-20251001',
  'claude-haiku-4-5',
] as const;
type ValidModel = typeof VALID_MODELS[number];

function getModel(): ValidModel {
  const configured = process.env.ANTHROPIC_MODEL?.trim();
  if (!configured) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('ANTHROPIC_MODEL não configurada. Defina nas variáveis de ambiente da Vercel.');
    }
    console.warn('[Claude] ANTHROPIC_MODEL não definida. Usando claude-sonnet-4-6 como fallback.');
    return 'claude-sonnet-4-6';
  }
  if (!VALID_MODELS.includes(configured as ValidModel)) {
    throw new Error(`ANTHROPIC_MODEL inválida: "${configured}". Valores aceitos: ${VALID_MODELS.join(', ')}`);
  }
  return configured as ValidModel;
}

const SYSTEM_PROMPT = `Você é a MESA TÉCNICA MULTIDISCIPLINAR do ContractCore, formada por 9 especialistas:
1. Jurídico corporativo | 2. RH | 3. Departamento Pessoal | 4. Contador
5. Advogado Trabalhista | 6. Advogado Direito da Saúde | 7. Especialista CFP/CRP
8. Psicólogo com visão ética | 9. Especialista em contratos empresariais

REGRAS:
- Contrato de PRESTAÇÃO DE SERVIÇOS AUTÔNOMA — nunca linguagem CLT
- Responda em português brasileiro claro, acessível ao leigo
- Seja ESPECÍFICO e DETALHADO — nunca genérico
- Identifique PROBLEMAS REAIS baseados nos dados fornecidos`;

export interface ClausulaRevisada {
  id:             string;
  chave:          string;
  titulo:         string;
  problema:       string;
  texto_original: string;
  texto_revisado: string;
  motivo:         string;
  gravidade:      'atencao' | 'importante' | 'critico';
  area:           string;
}

export interface EnrichContractInput {
  formData:     ContractFormData;
  company:      Company;
  contratoBase: string;
}

export interface EnrichContractOutput {
  contrato_html:        string;
  sugestoes:            string;
  riscos_identificados: RiscoItem[];
  nivel_risco:          'baixo' | 'medio' | 'alto';
  checklist_mesa:       ChecklistMesaItem[];
  clausulas_ajustadas:  string[];
  clausulas_revisadas:  ClausulaRevisada[];
  tokens_usados:        number;
}

function escapeHtml(v: string): string {
  return v.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
          .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

export async function enrichContractWithAI(input: EnrichContractInput): Promise<EnrichContractOutput> {
  const { formData, company, contratoBase } = input;
  const { provider, service, remuneration } = formData;

  // 1500 chars libera ~750 tokens de output extras para a análise completa
  const contratoTexto = contratoBase
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim()
    .slice(0, 1500);

  const objetoStatus = service.objeto
    ? `"${service.objeto.slice(0, 150)}"`
    : 'NÃO PREENCHIDO — CRÍTICO';
  const valorStatus = remuneration.valor_descricao
    ? `"${remuneration.valor_descricao.slice(0, 100)}"`
    : 'NÃO INFORMADO — CRÍTICO';
  const conselhoOk = provider.conselho_profissional && provider.numero_registro_conselho;

  const prompt = `Analise DETALHADAMENTE este contrato. Retorne análise completa com no mínimo 4 cláusulas revisadas.

═══ DADOS REAIS DO CONTRATO ═══
CONTRATANTE: ${company.razao_social} | CNPJ: ${company.cnpj} | ${company.cidade}/${company.uf}
CONTRATADA: ${provider.nome_razao_social} | ${provider.tipo_pessoa} | ${provider.profissao}
Conselho: ${conselhoOk ? `${provider.conselho_profissional} nº ${provider.numero_registro_conselho}` : 'NÃO INFORMADO — VERIFICAR'}
Especialidade: ${provider.especialidade || 'Não informada'}
Objeto: ${objetoStatus}
Descrição dos serviços: ${service.descricao_servicos || 'Não preenchida'}
Modalidade: ${service.modalidade} | Periodicidade: ${service.periodicidade}
Agenda: ${service.agenda_pactuada || 'Não informada'} | Local: ${service.local_prestacao || 'Não informado'}
Exclusividade: ${service.exclusividade ? 'SIM — ATENÇÃO' : 'NÃO'}
Cancelamento: ${service.regra_cancelamento || 'Não definida'} | Remarcação: ${service.regra_remarcacao || 'Não definida'}
Valor: ${valorStatus}
NF: ${remuneration.emite_nota_fiscal} | Pagamento: ${remuneration.data_pagamento} via ${(remuneration.formas_pagamento || []).join(', ')}
Retenções: ${remuneration.retencoes_fiscais || 'não especificadas'} | Modelos: ${(remuneration.modelos || []).join(', ')}

═══ TEXTO DO CONTRATO ═══
${contratoTexto}

═══ MISSÃO ═══
Retorne APENAS JSON válido (sem markdown). Schema compacto:

clausulas_revisadas (mín 4): id chave titulo problema(2-3 frases para leigo) texto_original(trecho real ≤200 chars) texto_revisado(versão melhorada ≥2 frases) motivo(1-2 frases) gravidade(atencao|importante|critico) area
riscos (mín 4): titulo(≤5 palavras) descricao(1 frase para leigo) gravidade(atencao|importante|critico) como_corrigir(1 frase) area(Trabalhista|Fiscal|LGPD|CFP/CRP|Contratual|Pejotização)
checklist (7 fixos): area status(ok|atencao|problema) observacao(1 frase)
  Areas: Trabalhista | Fiscal | LGPD | CFP/CRP | Pejotização(score 0-10) | Remuneração | Conselho

{"nivel_risco":"baixo|medio|alto","sugestoes":"5-8 frases específicas","clausulas_revisadas":[...],"riscos":[...],"checklist":[...]}

REGRAS: texto_original e texto_revisado REAIS e DIFERENTES. Se objeto/valor vazios → críticos. problema deve ser compreensível para leigo.`;


  const response = await client.messages.create({
    model:      getModel(),
    max_tokens: 2200,
    system:     SYSTEM_PROMPT,
    messages:   [{ role: 'user', content: prompt }],
  });

  const msgContent = response.content[0];
  if (msgContent.type !== 'text') throw new Error('Resposta inesperada da IA');

  const raw   = msgContent.text;
  const clean = raw.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();

  // LOG TEMPORÁRIO — remover após confirmar funcionamento
  console.log('[Claude] stop_reason:', response.stop_reason);
  console.log('[Claude] output_tokens:', response.usage.output_tokens);
  console.log('[Claude] raw (200 chars):', raw.slice(0, 200));
  console.log('[Claude] raw FINAL (200 chars):', raw.slice(-200));

  let parsed: {
    nivel_risco:         string;
    sugestoes:           string;
    clausulas_revisadas: ClausulaRevisada[];
    riscos:              RiscoItem[];
    checklist:           ChecklistMesaItem[];
  };

  try {
    const jsonMatch = clean.match(/\{[\s\S]*\}/);
    const jsonStr = jsonMatch ? jsonMatch[0] : clean;
    console.log('[Claude] JSON encontrado:', jsonStr.length, 'chars');
    parsed = JSON.parse(jsonStr);
    console.log('[Claude] Parse OK — nivel_risco:', parsed.nivel_risco, '| clausulas:', parsed.clausulas_revisadas?.length, '| riscos:', parsed.riscos?.length);
  } catch (parseErr) {
    console.error('[Claude] Parse FALHOU:', parseErr instanceof Error ? parseErr.message : parseErr);
    console.log('[Claude] clean completo:', clean.slice(0, 500));
    parsed = {
      nivel_risco:         'medio',
      sugestoes:           'A IA não conseguiu retornar análise estruturada. Verifique se os campos Objeto e Valor estão preenchidos e tente novamente.',
      clausulas_revisadas: [],
      riscos:              [],
      checklist:           [],
    };
  }

  const clausulasRevisadas = (parsed.clausulas_revisadas || []).filter(
    (cl) => cl && cl.titulo && cl.texto_revisado,
  );

  // Injeta seção de revisão no final do contrato — garantido independente dos títulos
  let contratoHtmlFinal = contratoBase;
  if (clausulasRevisadas.length > 0) {
    const cards = clausulasRevisadas.map((cl) => {
      const label = cl.gravidade === 'critico' ? 'Crítico' : cl.gravidade === 'importante' ? 'Importante' : 'Atenção';
      return (
        `<div class="ia-review-card ia-gravidade-${escapeHtml(cl.gravidade || 'atencao')}">` +
        `<div class="ia-review-kicker">Mesa Técnica · ${escapeHtml(cl.area || '')} · ${label}</div>` +
        `<h3 class="ia-review-titulo">${escapeHtml(cl.titulo || '')}</h3>` +
        `<p class="ia-review-problema"><strong>Problema:</strong> ${escapeHtml(cl.problema || '')}</p>` +
        `<p class="ia-review-revisado"><em>✦ Texto recomendado:</em> ${escapeHtml(cl.texto_revisado)}</p>` +
        `<p class="ia-review-motivo"><strong>Por quê:</strong> ${escapeHtml(cl.motivo || '')}</p>` +
        `</div>`
      );
    }).join('\n');

    const secao = `
      <div class="ia-review-section">
        <h2>✦ Revisão da Mesa Técnica Multidisciplinar</h2>
        ${cards}
      </div>`;

    // Inserir antes de </body> se existir, senão no final
    if (contratoHtmlFinal.includes('</body>')) {
      contratoHtmlFinal = contratoHtmlFinal.replace('</body>', secao + '</body>');
    } else {
      contratoHtmlFinal = contratoHtmlFinal + secao;
    }
  }

  return {
    contrato_html:        contratoHtmlFinal,
    sugestoes:            parsed.sugestoes || '',
    riscos_identificados: (parsed.riscos   || []) as RiscoItem[],
    nivel_risco:          (parsed.nivel_risco || 'medio') as 'baixo' | 'medio' | 'alto',
    checklist_mesa:       (parsed.checklist || []) as ChecklistMesaItem[],
    clausulas_ajustadas:  clausulasRevisadas.map(c => c.titulo),
    clausulas_revisadas:  clausulasRevisadas,
    tokens_usados:        response.usage.input_tokens + response.usage.output_tokens,
  };
}

export async function suggestContractObject(profissao: string, especialidade?: string): Promise<string> {
  const isDescricao = especialidade === 'descricao_detalhada';
  const prompt = isDescricao
    ? `Escreva a DESCRIÇÃO DETALHADA DE SERVIÇOS para contrato de prestação com ${profissao} em clínica de saúde. 2 parágrafos. Texto corrido. Sem títulos ou asteriscos. Mencione autonomia técnica.`
    : `Escreva o OBJETO de contrato de prestação de serviços autônoma para ${profissao} em clínica de psicologia. 2 parágrafos. Texto corrido. Sem títulos ou asteriscos. Autonomia técnica. Sem CLT.`;

  const response = await client.messages.create({
    model:      getModel(),
    max_tokens: 500,
    system:     SYSTEM_PROMPT,
    messages:   [{ role: 'user', content: prompt }],
  });

  const c = response.content[0];
  if (c.type !== 'text') return '';
  return c.text.replace(/\*\*/g, '').replace(/^#{1,6}\s*/gm, '').trim();
}